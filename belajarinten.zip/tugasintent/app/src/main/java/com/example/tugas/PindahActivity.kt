package com.example.tugas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PindahActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pindah)
    }
}